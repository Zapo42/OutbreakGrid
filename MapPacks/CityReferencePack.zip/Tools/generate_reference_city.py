"""Generate fictional building lots inside a surveyed street layout; preserve attribution and scale.

This first map-generation stage reuses the surveyed roads rather than synthesizing a new
street graph. Building footprints and entrance paths are newly generated from a seed.
"""
import argparse
from collections import deque
import json
import math
from pathlib import Path
import random

from shapely.geometry import box

import city_atlas as atlas


def unpack(document):
    width,height=document["width"],document["height"]
    cells=bytearray(width*height)
    for chunk in document["chunks"]:
        for i,tile in enumerate(chunk["cells"]):
            x,y=chunk["x"]*32+i%32,chunk["y"]*32+i//32
            if x<width and y<height:
                cells[y*width+x]=tile
    return cells


def pack(document,cells):
    width,height=document["width"],document["height"]
    chunks=[]
    for cy in range((height+31)//32):
        for cx in range((width+31)//32):
            values=[cells[y*width+x] if x<width and y<height else 0
                    for y in range(cy*32,cy*32+32) for x in range(cx*32,cx*32+32)]
            if any(values):chunks.append({"x":cx,"y":cy,"cells":values})
    document["chunks"]=chunks


def entrance_path(cells,width,height,left,top,w,h):
    """Four candidate doors; bounded multi-source BFS chooses a physical path to a sidewalk."""
    doors=[(left+w//2,top,0,-1),(left+w//2,top+h-1,0,1),
           (left,top+h//2,-1,0),(left+w-1,top+h//2,1,0)]
    queue=deque();parents={};origins={}
    for door in doors:
        x,y,dx,dy=door;outside=(x+dx,y+dy)
        if 0<=outside[0]<width and 0<=outside[1]<height and cells[outside[1]*width+outside[0]] in (0,5,6):
            queue.append(outside);parents[outside]=None;origins[outside]=door
    while queue and len(parents)<=10000:
        position=queue.popleft();x,y=position
        if cells[y*width+x] in (5,6):
            path=[];door=origins[position]
            while position is not None:
                path.append(position);position=parents[position]
            return door,path
        for dx,dy in ((0,-1),(1,0),(0,1),(-1,0)):
            nxt=(x+dx,y+dy);nx,ny=nxt
            if not (0<=nx<width and 0<=ny<height) or nxt in parents:
                continue
            if left<=nx<left+w and top<=ny<top+h or cells[ny*width+nx] not in (0,5,6):
                continue
            parents[nxt]=position;origins[nxt]=origins[(x,y)];queue.append(nxt)
    return None


def generate(sample,features,provenance,seed,cell_metres=5,max_buildings=128):
    if not isinstance(seed,int) or not 1<=seed<=4294967295:
        raise ValueError("Seed must be between 1 and 4294967295")
    if not 1<=max_buildings<=256:
        raise ValueError("Choose between 1 and 256 buildings")
    projected,grid,metrics=atlas.survey(features,sample["bbox"],cell_metres)
    blocks=[g for g,p in projected if p["category"]=="block"]
    if not blocks:
        raise ValueError("Reference has no complete street-enclosed blocks for safe lot generation")
    # Use surveyed road/water geometry; source buildings are measurements, not fictional occupants.
    backbone=[(g,p) for g,p in projected if p["category"] in ("road","water")]
    document=atlas.export_map(sample,backbone,grid,provenance)
    cells=unpack(document);original=bytes(cells);width,height=grid["width"],grid["height"]
    recipes=[]
    for geometry,props in projected:
        if props["category"]!="building" or geometry.area<=0:
            continue
        coords=list(geometry.minimum_rotated_rectangle.exterior.coords)
        if len(coords)<4:continue
        sides=[math.dist(coords[i],coords[i+1])/cell_metres for i in (0,1)]
        recipes.append(tuple(max(4,min(12,round(length))) for length in sides))
    fallback=not recipes
    if fallback:recipes=[(5,7),(6,8),(5,5)]
    coverage=metrics["building_coverage"] if metrics["building_coverage"] is not None else .12
    coverage=max(.03,min(.3,coverage))
    average_cells=sum(w*h for w,h in recipes)/len(recipes)
    rng=random.Random(seed);buildings=[];occupied=set()
    for block_index,block in enumerate(blocks):
        inner=block.buffer(-cell_metres*2)
        if inner.is_empty:continue
        x0,y0,x1,y1=inner.bounds
        target=max(1,min(24,round(block.area*coverage/(cell_metres**2*average_cells))))
        placed=0
        for _ in range(target*100):
            if placed>=target or len(buildings)>=max_buildings:break
            w,h=rng.choice(recipes)
            if rng.randrange(2):w,h=h,w
            minimum_x,minimum_y=math.ceil(x0/cell_metres),math.ceil(y0/cell_metres)
            maximum_x,maximum_y=math.floor(x1/cell_metres)-w,math.floor(y1/cell_metres)-h
            if maximum_x<minimum_x or maximum_y<minimum_y:continue
            left,top=rng.randint(minimum_x,maximum_x),rng.randint(minimum_y,maximum_y)
            if left<1 or top<1 or left+w>=width or top+h>=height:continue
            geometry=box(left*cell_metres,top*cell_metres,(left+w)*cell_metres,(top+h)*cell_metres)
            if not inner.covers(geometry):continue
            footprint={(x,y) for y in range(top,top+h) for x in range(left,left+w)}
            if any(cells[y*width+x]!=0 or (x,y) in occupied for x,y in footprint):continue
            connection=entrance_path(cells,width,height,left,top,w,h)
            if connection is None:continue
            door,path=connection
            for x,y in footprint:
                cells[y*width+x]=8 if x in (left,left+w-1) or y in (top,top+h-1) else 7
            cells[door[1]*width+door[0]]=9
            for x,y in path:
                if cells[y*width+x]==0:cells[y*width+x]=5
            occupied.update((x,y) for y in range(top-1,top+h+1) for x in range(left-1,left+w+1))
            buildings.append({"left":left,"top":top,"width":w,"height":h,"door":[door[0],door[1]],"block":block_index,"path_cells":path})
            placed+=1
    if not buildings:
        raise ValueError("No safe building fits this reference at the selected scale")
    # Preserve every original corridor and water cell exactly.
    if any(tile in (5,6,12) and cells[i]!=tile for i,tile in enumerate(original)):
        raise AssertionError("Lot generation changed the surveyed street backbone")
    metadata={"schema_version":1,"seed":seed,"reference_id":sample["id"],"reference":sample,
              "provenance":provenance,"grid":grid,"buildings":buildings,
              "source_block_count":len(blocks),"target_coverage":coverage,
              "footprint_recipe_source":"explicit fallback — reference has no buildings" if fallback else "surveyed footprints, adapted to 4–12 game cells per side",
              "scope":"Surveyed street backbone; fictional seeded buildings and doors. No population, assigned roles, supplies or vehicle lanes."}
    document["id"]="generated-reference-"+sample["id"]+"-"+str(seed)
    document["name"]="Generated "+sample["id"]+" district (seed "+str(seed)+")"
    document["authoringJson"]=json.dumps(metadata,ensure_ascii=False,sort_keys=True)
    pack(document,cells)
    artwork=backbone+[(g,p) for g,p in projected if p["category"]=="block"]
    for i,building in enumerate(buildings):
        x,y,w,h=(building[k] for k in ("left","top","width","height"))
        artwork.append((box(x*cell_metres,y*cell_metres,(x+w)*cell_metres,(y+h)*cell_metres),{"category":"building","source_id":"fictional/"+str(i)}))
    return document,metadata,atlas.svg_map(artwork,grid,metrics)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference",required=True)
    parser.add_argument("--seed",type=int,default=214)
    parser.add_argument("--max-buildings",type=int,default=128)
    parser.add_argument("--atlas",type=Path,default=atlas.ROOT/"CityReferences/atlas")
    parser.add_argument("--output",type=Path,default=atlas.ROOT/"CityReferences/generated")
    args=parser.parse_args()
    if not args.reference or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789-" for c in args.reference):
        parser.error("Reference id must contain lowercase letters, digits and hyphens")
    source=json.loads((args.atlas/(args.reference+".geojson")).read_text())
    profile=json.loads((args.atlas/(args.reference+".profile.json")).read_text())
    document,metadata,artwork=generate(profile["sample"],source["features"],profile["provenance"],args.seed,profile["grid"]["cell_metres"],args.max_buildings)
    stem=args.reference+"-"+str(args.seed)
    atlas.write_json(args.output/(stem+".obmap2"),document)
    atlas.write_json(args.output/(stem+".generation.json"),metadata)
    (args.output/(stem+".svg")).write_text(artwork)
    print(f'Generated {stem}: {len(metadata["buildings"])} buildings with physical doors and street paths')


if __name__=="__main__":main()
