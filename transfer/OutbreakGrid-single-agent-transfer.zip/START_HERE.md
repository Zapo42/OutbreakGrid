# Single-agent consolidation handoff — OutbreakGrid

The user is consolidating development to ONE agent. This replaces earlier specialist/team ownership instructions for future work. Do not spawn a replacement team or wait for a separate NPC coder/Lead to own routine edits. Read the preserved AGENTS/role files as historical project context, then reconcile the active instructions with this user decision. Work locally; publication is not authorized by this package request.

**This is a complete transfer of the source/history/inputs/evidence available to this NPC workspace, plus all currently published branches fetched read-only. It is NOT a claim all candidates are merged or release-ready. Other agents' unpublished/uncommitted files outside this workspace cannot be included or certified.**

## Read these first

1. This file, then `STATE_AND_LIMITS.md` and `CONSOLIDATION_PROMPT.txt`.
2. `evidence/NPC-F143/HANDOFF.md` (latest NPC correction) and `evidence/NPC-F141-R1/README.md` (prior correction and unresolved survival regression).
3. `evidence/store-baseline-validation/DIAGNOSTIC_RESULTS.md` and `inputs/store-validation/NPC_HANDOFF.md` for the actual store fixtures.
4. `candidates/lead-integration/PLANS.md`, its current AGENTS.md and UI validation record. These preserve known integration tasks, but its old multi-agent restrictions are superseded by the user's consolidation decision.
5. World handoffs under `candidates/world-store-handoff/handoffs/world/`. Preserve the generator/reference changes; do not substitute an older game source tree.

## Exact source choices — do not confuse these

| Payload | Revision | Meaning |
| --- | --- | --- |
| `source/` |65b59c9f513762f1a1136f7e83d32fb84c7fdede|Latest tested NPC project tree: Lead c67eeca + local R1 + F143.711core cases/743692assertions, ABI/UI2477/3; does NOT contain the newer UI transfer. |
| `candidates/lead-integration/` |21338cff62526f4615195299b39392a0359e8917|Newer published Lead candidate with UI-PRES-01/01A merged.701core/743092, ABI/UI4899/3 in its recorded validation. Does NOT contain local R1/F143. |
| `candidates/world-store-handoff/` |b78fccc64ee9c81ea2f4b92f71054d9db674cf28|World generator/store interiors19e18e7 + fixtures efa3634 + published packet. Its underlying game is OLDER rules97. Review/import the narrow World/fixture changes; NEVER replace modern NPC/Lead Core with this tree. |
| `inputs/store-validation/` |packet efa3634|Checksummed original four paused NPC137/rules106/schema14 fixtures and exact matching reader snapshot. Preserve originals; explicit upgraded copies were used to test current107. |
| Published `main` at packaging |1b05a73c0994720230524c519dac84fc58d0bbd3|Foundation131+World. Newer candidate work is not released. |

Remote refs were fetched read-only during packaging. Local source branch remains `npc/f143-interior-doors` at65b59c9 and clean. No merge, push or deployment was performed to assemble this transfer.

## Recommended consolidation path

Use the newer Lead candidate21338cf as the review base, then apply the two local NPC commits in order:

- b6c2b9a6772310cba35f32689823e12b7d2543f9 — NPC-F141-R1, courier recovery budgeting and unusable claims.
- 65b59c9f513762f1a1136f7e83d32fb84c7fdede — NPC-F143, clerk/pantry internal-door opening.

A detached file-copy check confirmed both patches apply sequentially to21338cf and reconstruct all nine changed NPC files exactly as in the tested65b59c9 source, while preserving the newer Lead UI. **The resulting combined tree was not compiled or simulated as part of packaging.** Run integrated checks before calling it validated.

Next review/select the narrow World19e18e7 and fixture efa3634 changes from the preserved branch. `history/WORLD_STORE_CHANGED_PATHS.txt` identifies the seven store increment paths; `history/WORLD_STORE_AND_FIXTURE.patch` preserves the narrow post28dcbab commits. The branch's rules97 Core is not a modern replacement. UI1826dc6 is already in Lead21338cf; do not apply it twice.

NPC-F142 (280753ae347aa4bbd0dcd5e9a6a7e5ca6a39bf8f) is a separate historical investigation branch, not missing gameplay. Keep its diagnostics/history available, but do not blindly run its hardcoded7/4 old-bug comparisons against fixed source or merge old source wholesale. F138–F141 diagnostics/prerequisites are already in the modern source ancestry.

The historical `work` checkout72a80e6 had a dirty PLANS.md. Its exact patch and content are preserved in `history/root-work-uncommitted.patch` and `root-work-PLANS-uncommitted.md`; review as old planning context, not the current integration plan. Old `/tmp` worktrees are recorded but their missing directories were not fabricated or pruned. All reachable commits/heads are preserved in the offline bundle.

## Offline restore and branch import

Verify payload files first:

```sh
python3 VERIFY.py
```

To restore the latest tested NPC project with full source history:

```sh
git clone --branch npc/f143-interior-doors history/OutbreakGrid-all-local.bundle OutbreakGrid
cd OutbreakGrid
```

The bundle is complete, with no Git-history prerequisites. Normal clone imports local-head history. Fetch the frozen remote-branch snapshots explicitly to access the newer Lead/World candidates:

```sh
git fetch ../history/OutbreakGrid-all-local.bundle 'refs/remotes/origin/*:refs/remotes/transfer-snapshot/*'
git switch -c consolidation-review transfer-snapshot/lead/npc-f141-integration-20261028
git cherry-pick b6c2b9a6772310cba35f32689823e12b7d2543f9 65b59c9f513762f1a1136f7e83d32fb84c7fdede
```

Adjust the bundle path if the clone is elsewhere. No main reset/force push. `source/` is an immediately inspectable Unity project tree if Git is unavailable, but does not include .git history. Never copy all three snapshots over one another.

`history/NPC-R1-and-F143.patch` is the two-commit alternative for a suitable Lead baseline. The individual patches, detailed evidence and original packets are also retained. Binary Git/source archives include tracked assets and .meta files, not credentials/config, caches, Unity Library or installed SDKs. Preserve GUIDs when integrating.

## Verification and running

Keep Unity6000.6.3f1. Native Unity/player testing has been paused since the user's Foundation82 checkpoint; no later hosted result establishes actual native behavior. RESTORE42 permanently peels to49fc25b05567c4ec6b22acb03a9df98da3b39c76. Foundation82 tag peels to0fc9522513593d7585de88d9fc2a356dcd52dfe7. Both tags are in the bundle, unchanged. No EXE is claimed or supplied.

Use .NET8 for hosted checks. In the chosen integrated checkout:

```sh
python3 OutbreakRebuild/Tools/run_checks.py --dotnet dotnet --output /path/to/check-results
```

Run test projects sequentially within one checkout; several share obj intermediates. Additional Lead UI/World checks and World Python/generator checks are documented in their handoffs and should be repeated on the actual combined tree. Newer UI4899assertions are not covered by the old UI2477NPC run. Do not conflate those baselines.

A portable store runner is provided; it links source read-only and creates temporary isolated build intermediates:

```sh
python3 tools/run_store_validation.py --source /path/to/combined/OutbreakGrid --dotnet dotnet --rules 107 --output /path/to/store-results
```

Without `--source`, it uses packaged `source/`. Use `--rules 106` to reproduce original legacy behavior. It preserves fixture inputs and changes only the rule selection on a detached runtime copy. It records failures rather than artificially changing stocks/destinations. Diagnostics exiting0 means accounting/replay completed, not every requested gameplay outcome passed. Source SDK/tool installs are not bundled; restore the toolchain using project docs rather than copying old absolute paths.

## What is still unsafe to claim

- This is NOT a released combined build. Main remains older and all new consolidation needs integrated review.
- R1 fixes generated-city deliveries4→9(old1067), but its older64x36cartographer survival comparison worsens7→9deaths. That remains unresolved.
- F143 fixes real internal-door execution. In the new four store fixtures it enables real purchases/home resupply and credits9/17/15/15 instead of8/0/0/0. The delivery case still has two later deaths; hard-case next-day attendance remains incomplete.158meals remain in that delivery trial,156in DC stock: useful distribution/needs priorities are still inadequate.
- Old106 saves intentionally keep old behavior until explicitly upgraded; no hidden save migration occurred.
- The original unrelated four-death report lacked its exact original save/revision. Do not claim these fixtures reproduce it by assertion.

## Delivery preference and takeover

The user asked to consolidate to one agent and keep work local. Supply reviewable packages when requested, with a copy-paste takeover prompt every time. Do not publish simply because an old role file describes an incremental GitHub workflow. Ask for publication only when needed and not already authorized. Do not send Slack/email/messages or claim external-agent coordination.

Numbered next-step options after completing an increment remain the user's preference. Finish the chosen increment before offering adjacent systems. No new staffing, stock refills, vehicle capacity/speed changes, weapons in storage, happiness bonuses or new stores should be added merely to mask current problems.
