# OutbreakGrid — single-agent takeover

Start with this file, TAKEOVER-PROMPT.md, the approved visual reference and implementation-and-evidence/HANDOFF.md. This package transfers Graphics & UI work and the cloud preparation performed in this conversation. It is not a complete handoff from the separate Lead, NPC or World sessions; their latest unpublished work remains external and must be reconciled before integration.

## Latest user direction and authority

The user is consolidating development into one agent. Do not start specialists or require the old multi-agent ownership ceremony for consolidation; current user instructions take precedence over historical role descriptions. Preserve existing architecture, gameplay and user work. Do not infer permission for unrelated gameplay, dependency upgrades, publication or resuming native testing. This request authorizes packaging/transfer, not a new art implementation.

## Verified repository state

- Repository: Zapo42/OutbreakGrid.
- Checkout: /workspace/OutbreakGrid.
- Branch: transfer/ui-pres-01-01a.
- HEAD/transfer commit: 1826dc6fbb8b9b122816dcca0f93177e6622be0b.
- Parent/base: f1b170bab2d6565097b292d0d83883f3c352afd6 (Foundation 131).
- Working tree clean when packaged.
- Remote branch was pushed by explicit user request and reverified with git ls-remote during packaging; it points to the full transfer commit above.
- No merge into main, release publication or PR creation performed here. The transfer branch push is distinct from final integration/publication.
- No newly created Git worktrees. Use the existing isolated cloud checkout where appropriate.

## Completed implementation: UI-PRES-01 and UI-PRES-01A

Only three tracked files changed in the transfer commit:
1. Assets/Outbreak/Unity/NeedBarsPresentation.cs: clamp the full existing selected-only need-label stack to the bottom edge as well as the top, including post-cull motion offsets.
2. Assets/Outbreak/Unity/FoundationApp.cs: only the DrawNpcBars call argument visible -> bounds, plus an explanatory comment. Bars may occupy blank map-panel padding and remain clear of toolbar, inspector and status area.
3. Tests/UiHarness.cs: additive label-rectangle capture, edge/state/value/toggle tests and actual DrawWorld small-map/span256 regressions.

Paths above are relative to OutbreakRebuild/. Existing colors, selected-only/optional toggle semantics, descending food, label meanings, occupation outlines, simulation decisions, formulas, save state, camera, World geometry, dependencies and Unity pin were preserved. No asset or GUID work. No gameplay or pixel-art rollout was implemented.

## Validation and evidence

Final combined checks ran sequentially on the final source before commit; committing did not change source:
- Legacy UI PASS: 4885 assertions.
- NewOnly UI PASS: 3 assertions; input-disabled diagnostic only, not Legacy drawing coverage.
- Project configuration PASS: Unity 6000.6.3f1 target/module baseline.
- git diff --check PASS.
- New actual-DrawWorld regression failed with the old visible call and passed with bounds. Original placement regression failed before the bottom clamp. These expected pre-fix failures are explicitly preserved as before evidence.

The small-map check uses CombatFootworkTest (7x5), span 256 and three screen sizes including the minimum 64x64 map-panel allocation. It checks labels/backgrounds/fills, blank-padding use, actor-relative alignment, adjacent UI exclusion and unchanged Documents.Encode(world.Capture())/world.Tick. The prior tiny-terrain-rectangle issue is resolved under the user's explicitly approved full-panel policy; it is not an outstanding blocker.

Exact commands, cwd and zero exit statuses: implementation-and-evidence/validation.json. Logs/reports and the original detailed handoff are adjacent. Native Unity import, actual rendering/input/text metrics/clipping, native dialogs and Windows player were NOT RUN; native Unity testing remains paused. The integrated full core/unified runner was not rerun for this presentation-only increment. A previous onboarding run on the Foundation 131 base passed 627 core cases/737155 assertions, Windows ABI and UI 2463/3; those historical counts do not validate newer NPC/World/Foundation 132 integration.

## Integration / source transfer

Preferred source is the pushed transfer branch. Inspect the actual destination HEAD/status before doing anything. Preserve uncommitted work. Determine whether 1826dc6 or equivalent changes are already integrated; do not apply twice. Fetch the branch and inspect the one commit against its parent. If absent and compatible, apply/cherry-pick the transfer commit into the chosen integration branch. Do not reset main or overwrite current files.

The combined-three-file.patch is an alternative to the commit, not an additional required application. It includes both increments against Foundation 131. Never replace entire newer UI files with baseline copies: preserve unpublished Foundation 132 assertions and newer NPC/World behavior while resolving individual hunks. FoundationApp.cs must receive only the authorized call-site change/comment from this increment.

outbreakgrid-ui-transfer.bundle is a self-contained Git bundle containing the transfer branch and reachable history. It offers an offline fallback if GitHub or this workspace is unavailable. Example inspection: git bundle list-heads outbreakgrid-ui-transfer.bundle. To fetch into an existing repository: git fetch /absolute/path/outbreakgrid-ui-transfer.bundle refs/heads/transfer/ui-pres-01-01a:refs/remotes/transfer-package/ui-pres-01-01a. Inspect before integrating. No credential values are stored in this package.

Read current instructions/roadmaps in the actual integration checkout. source-records/ holds historical reference copies only; do not copy those over newer instructions. The pinned Lead assignment is also included for context. The Lead was coordinating a separately active NPC coder, unpublished Foundation 132 happiness work and World residential-generation work. Their latest outputs and completion/integration state are UNKNOWN here. A prior Lead record mentions Foundation 132 at 72a80e6, but that implementation was absent locally; do not reconstruct or call it complete from that mention.

## Approved graphics direction

The user requested 'the most advanced simulation the 80s could manage': sophisticated simulation shown through exceptionally simple low-resolution marks, inspired by Dwarf Fortress and an early color LCD. NPCs should occupy single pixels to tens of pixels, not detailed miniature people. A first, much more detailed concept was rejected and is intentionally not included.

The user liked the subsequent image visual-reference/approved-pixel-scale-study.png. Treat this as the approved visual direction, not a production-ready sprite atlas. Generated imagery does not establish exact source dimensions, glyph masks or palette counts. No production sprites, materials, shader, font or renderer changes have been made.

Working visual proposal:
- Native 320x200 reference canvas, sharp integer scaling, a restrained 16-color palette derived from current identities.
- Compare 1-2-pixel distant NPCs, 3x3 compact symbols and 3x5 slightly more readable symbols.
- Recommendation offered: 3x3 as the main target, distant single-pixel marks, 3x5 only if occupations need it. The user approved the sheet's look, not an explicit exact glyph-size/LOD contract. Final grids/zoom transitions still need a concrete implementation decision.
- Dark quiet terrain, warm homes/boxes, dusty-blue stores/vehicles, sage warehouse identity, olive infected, cyan/amber highlights.
- Glow stays off while silhouettes/readability are established. Later add only faint LCD glow/pixel structure. No CRT curvature, strong blur or modern neon treatment.
- Proposed reference palette, not yet enforced in application: #101820 #26333B #454C50 #80877A #C6C7AE #5C6B3C #87944D #BA975F #79583D #454F6B #7097AE #56715E #78B7B0 #C5A04A #AD5348 #E0C87A.

## Requirements to preserve

- Information organized around the selected item, with collapsible encounter sections.
- Current previews easy to find; historical previews in Old Test Scenarios.
- Simulation speed controls, Main Menu and Restart Scenario.
- Selected-only optional H/F/E bars and descending food display.
- Readable building/storage identities, door states and occupation outlines.
- Presentation displays authoritative simulation state and issues supported commands; do not move decisions into graphics/animation.
- Preserve existing colors, detail and recognizable identities incrementally.
- Unity 6000.6.3f1 and dependency versions unchanged. Preserve GUIDs/.meta files.
- DragonGlassPixelWorkshop source was not found; no project import or Workshop integration without explicit authorization.
- Native Unity testing remains paused; API-double results must remain distinct from real rendering/input.

## Planned visual sequence (not completed implementation)

1. Lock pixel scale/palette with the approved reference sheet — concept stage done; exact production masks/palette still to establish.
2. Select an existing representative scenario with humans/infected, doors, storage, buildings and vehicles as the repeatable visual test scene.
3. Implement a small NPC glyph increment; preserve selection, occupations and need bars. Verify masks/geometry with hosted checks; record native appearance as unverified while testing is paused.
4. Extend the quiet terrain tile language, keeping open/closed doors/windows/blocked cells clear.
5. Simplify building/storage/vehicle symbols while preserving identities and paint colors.
6. Add restrained animation only from authoritative state/events.
7. Apply readable bitmap-style instrument-panel UI without removing current controls/organization.
8. Add optional restrained LCD treatment last, with an off setting and crisp text.
9. Check density, overlap, edges, zoom and rendering cost; verify native appearance when testing resumes.

The next code task should be a small production NPC-glyph increment after integration and current-source inspection. This transfer request does not itself authorize undertaking that implementation or changing gameplay task order.

## Environment reproduction and useful commands

Python 3 and verified .NET SDK 8.0.427 were prepared in /workspace/toolchains. The public SDK download was verified against the published SHA-512; no TLS/checksum bypass. environment/setup-outbreak.sh reproduces the SDK and runs the full hosted runner; it does not change dependency pins or tracked project files. It requires Python with tarfile data-filter support and normal package-download access.

For commands in this existing cloud machine:
export DOTNET_CLI_HOME=/workspace/toolchains/dotnet-home
export DOTNET_CLI_TELEMETRY_OPTOUT=1
export NUGET_PACKAGES=/workspace/toolchains/nuget
cd /workspace/OutbreakGrid/OutbreakRebuild
python3 Tools/check_project_config.py
/workspace/toolchains/dotnet/dotnet run --project Tests/UiChecks.csproj --no-launch-profile -p:InputMode=Legacy -- /tmp/takeover-legacy.txt
/workspace/toolchains/dotnet/dotnet run --project Tests/UiChecks.csproj --no-launch-profile -p:InputMode=NewOnly -- /tmp/takeover-newonly.txt
python3 Tools/run_checks.py --dotnet /workspace/toolchains/dotnet/dotnet

Run builds sequentially: test projects share obj state. Default runner output is a fresh temporary directory; never select tracked Examples for onboarding/test artifacts. Initialization initially needed the supported sandbox permission escalation for a .NET mutex; later runs succeeded normally. Existing GitHub HTTPS-proxy authentication supported reads and the explicitly authorized transfer push. No new credentials were requested. Installation/startup instructions were saved in the cloud environment draft; publication/fresh-task restoration was not verified here.

## Immediate takeover checklist

1. Read current destination instructions and inspect actual HEAD, status and all outstanding work.
2. Obtain the separate Lead/NPC/World handoffs or branch/commit identities; reconcile unknown Foundation 132 work without overwriting it.
3. Inspect/fetch the verified UI transfer branch; integrate once, preserving newer code and assertions.
4. Run sequential UI/config checks, then unified hosted checks on integrated source; update integrated validation records.
5. Confirm the next small visual implementation scope from the approved image and current renderer; preserve all requirements above.
6. Continue as one agent. Keep native verification paused and final publication subject to the user's actual authorization.
