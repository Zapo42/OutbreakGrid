#!/usr/bin/env bash
set -euo pipefail
mkdir -p /workspace/toolchains
python3 - <<'PY'
import hashlib, pathlib, subprocess, tarfile
root = pathlib.Path('/workspace/toolchains')
sdk = root / 'dotnet'
exe = sdk / 'dotnet'
version = '8.0.427'
if not exe.exists() or subprocess.check_output([str(exe), '--version'], text=True).strip() != version:
    archive = root / 'dotnet-sdk.tar.gz'
    subprocess.run(['curl', '-fsSL', 'https://builds.dotnet.microsoft.com/dotnet/Sdk/8.0.427/dotnet-sdk-8.0.427-linux-x64.tar.gz', '-o', str(archive)], check=True)
    expected = '85725692f465f5024b9b42a159a29d9f73e8c57ad9e8bfe1e7028a505d18031d68931e8aa3f9de44145b08170dde897c8a78e1aa18d4219698b6891af7095d39'
    if hashlib.sha512(archive.read_bytes()).hexdigest() != expected:
        raise RuntimeError('SDK SHA-512 mismatch')
    sdk.mkdir(exist_ok=True)
    with tarfile.open(archive) as bundle:
        bundle.extractall(sdk, filter='data')
    archive.unlink()
subprocess.run([str(exe), '--version'], check=True)
PY
export DOTNET_CLI_HOME=/workspace/toolchains/dotnet-home
export DOTNET_CLI_TELEMETRY_OPTOUT=1
export DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1
export NUGET_PACKAGES=/workspace/toolchains/nuget
cd /workspace/OutbreakGrid/OutbreakRebuild
python3 Tools/run_checks.py --dotnet /workspace/toolchains/dotnet/dotnet

