# UI-PRES-01 + UI-PRES-01A — combined handoff

Status: implementation and assigned hosted validation PASS. Ready for acting Lead integration/QA. The earlier small-map terrain-extent limitation is resolved by the explicitly authorized policy: need bars use the full map panel, including blank padding. No publication, merge, commit, reset or branch change performed.

## Baseline and ownership

HEAD remains f1b170bab2d6565097b292d0d83883f3c352afd6 (Foundation 131). Before UI-PRES-01A, the only local changes were the two UI-PRES-01 files. No new NPC/World changes or Foundation 132 edits were present in this checkout; none were overwritten or reconstructed. The original assignment was read at 8471907078c4d183d944af475a1fac1911c56601:PLANS.md. The user explicitly authorized UI-PRES-01A and the one-line call-site/comment extension to FoundationApp.cs.

Changed files, exactly:
- OutbreakRebuild/Assets/Outbreak/Unity/NeedBarsPresentation.cs: original UI-PRES-01 bottom clamp for the whole existing label stack.
- OutbreakRebuild/Tests/UiHarness.cs: additive label-rectangle capture, original selected need-bar regression checks, and new actual-DrawWorld small-map checks.
- OutbreakRebuild/Assets/Outbreak/Unity/FoundationApp.cs: only DrawNpcBars(i,body,actor,visible,cell) -> DrawNpcBars(i,body,actor,bounds,cell), plus its explanatory comment. No other edits to this shared file.

Existing colors, H/F/E meanings, toggles, descending food, selection/occupation outlines, NPC decisions/fields/interfaces, World geometry, camera, dependencies and Unity 6000.6.3f1 remain unchanged. No assets, GUIDs, scenes or settings touched. All existing local harness assertions remain. The Lead must retain unpublished Foundation 132 assertions during integration; those sources are absent here.

## Before/after evidence

1. UI-PRES-01 original production placement + new edge regression: FAIL exit 1, final E label outside bounds after post-cull bottom/right motion. See ui-pres-01-original-placement-failure.log.
2. UI-PRES-01A new actual-DrawWorld regression + old visible argument: FAIL exit 1, "Small-map bars were clamped to terrain bounds instead of the allocated panel." See before-legacy.log. This proves the new check detects regression of the assigned call-site change.
3. Combined change final Legacy UI: PASS exit 0, 4885 assertions (previous UI-PRES-01: 4816).
4. Final NewOnly UI: PASS exit 0, 3 assertions. This mode verifies disabled-input guidance; the drawing checks execute in Legacy.
5. Project configuration: PASS exit 0, Unity 6000.6.3f1 target/module baseline.
6. git diff --check: PASS exit 0.
7. Combined patch matches working changes: git apply --reverse --check <combined-three-file.patch> PASS, read-only.

## New UI-PRES-01A regression

CheckSmallMapNeedBars calls actual FoundationApp.DrawWorld by reflection with the existing CombatFootworkTest fixture (7x5), span 256 and all three need toggles enabled. It runs at 364x248 (the app's minimum 64x64 allocation), 1280x800 and 1920x1080 screens. The test restores screen dimensions and destroys its component afterward.

It verifies:
- Exactly H/F/E labels and three backgrounds for the selected human; the unselected zombie does not add bars.
- Every submitted label, background and full-value fill rectangle lies inside the allocated map panel.
- Toolbar, inspector and status regions remain clear, using their current app coordinates; strict panel containment also checks the surrounding gaps.
- The last label actually occupies permitted blank padding outside the tiny terrain extent, so this is not just a nominal small-map test.
- At 1280x800 the selected actor has ample horizontal panel room. Bars retain their normal alignment with the recorded selected body; the old terrain-bound argument incorrectly shifts them left and fails the test.
- Documents.Encode(world.Capture()) and world.Tick remain unchanged after each DrawWorld pass.

Prior UI-PRES-01 coverage remains: all four edges/corners and center at supported zoom extremes, all toggle combinations including post-cull motion, defaults/selection, valid human/zombie/dead states, disabled features, empty/half/full values and colors/order, preserved interior geometry/font size, and actual deferred-button state/tick invariance.

## Exact final validation

Working directory: /workspace/OutbreakGrid/OutbreakRebuild
Environment for dotnet:
DOTNET_CLI_HOME=/workspace/toolchains/dotnet-home
DOTNET_CLI_TELEMETRY_OPTOUT=1
NUGET_PACKAGES=/workspace/toolchains/nuget

Commands executed sequentially:
1. python3 Tools/check_project_config.py
2. /workspace/toolchains/dotnet/dotnet run --project Tests/UiChecks.csproj --no-launch-profile -p:InputMode=Legacy -- /tmp/ui-pres-01a/final-legacy-report.txt
3. /workspace/toolchains/dotnet/dotnet run --project Tests/UiChecks.csproj --no-launch-profile -p:InputMode=NewOnly -- /tmp/ui-pres-01a/final-newonly-report.txt
4. git diff --check

validation.json records exact argv, working directory and all zero exit codes. Final logs and reports are copied alongside this handoff. before-legacy.log records the deliberate pre-fix failure; it is not counted as a passing run. No production changes followed final validation.

## Integration and limits

combined-three-file.patch contains both UI-PRES-01 and UI-PRES-01A against f1b170b. If UI-PRES-01 is already integrated, do not apply its changes twice. On the actual Foundation 132 checkout, inspect current changes/ownership, run git apply --check, and resolve context by porting only the additive harness changes, the tiny bottom clamp and the one call-site argument/comment. Never replace the whole UI harness or FoundationApp.cs; preserve newer NPC/World work and Foundation 132 assertions. Existing shared-file context may differ; that is not authorization to overwrite it.

Lead owns final integrated unified validation, independent QA, plan/build-validation/build-log updates and publication. No core/unified suite rerun was needed for this scoped presentation change; it remains the Lead's integration check. The handoff supplies build-log evidence without editing Lead-owned records.

Evidence covers production drawing/dispatch through UI API doubles and submitted rectangles. Native rendering, text metrics, actual clipping/layout, native input, Unity import and Windows player were NOT RUN. Native Unity testing remains paused. No remaining assigned hosted-check failures or unresolved tiny-map policy decision.

Next authorized task: none beyond Lead integration/review. The separate pixel-art direction remains single-pixel to tens-of-pixels NPCs, very low resolution, limited palette and faint LCD glow; no art rollout is included here.
