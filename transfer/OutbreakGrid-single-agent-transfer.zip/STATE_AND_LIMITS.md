# NPC state, constraints and unresolved work

## Implemented ancestry

NPC132: saved happiness−50..+50, charisma-based social/environment preferences and inspectable contributors. NPC133: employment stays assigned, off-duty unencumbered workers temporarily act as consumers. NPC134: remembered park visits/physical leisure routes. NPC135: safe mutual greetings. NPC136: park preferences using actual visible company. NPC137: bounded familiar-person memory from actual greetings. Parks/bars as facility bonuses, happiness-related energy advantages and new leisure buildings remain separate future work.

NPC138: daily-routine observation and cartographer coordination brief.139: hunger/home/return priority investigation.140: courier throughput accounting.141: current107 safe carried meals and off-duty home return, plus saved gates preserving old106; initial generated delivery regression7→4.142: isolated paired investigation identifying meal timing and empty-return claims; diagnostic-only historical branch.141-R1: finite recovery/dispatch/claim correction, generated9deliveries.143: normal action door opening for clerk work/pantry inspection, with paid subsequent movement.

Base game already includes humans/zombies, combat/shoves/grapples, health/infection/death/reanimation, food/energy, food-only inventories/boxes/shelves, homes/shops/clerks/couriers/shifts, physical transfers, vehicles/use/load/unload, roads/pedestrian routes and scenario controls. Source/tests establish exact behavior; this list is not a fresh comprehensive validation.

## Preserve these rules

- Knowledge comes from authored familiarity, observation or established reports. No hidden-stock or actor knowledge.
- Food and cargo are finite; transfers occur physically. Do not teleport people or remotely move supplies.
- Actual movement consumes energy; existing exhaustion can charge hunger. Decorative idle animation remains separate/free.
- Urgent needs, danger, infection, injury and work precede optional leisure.
- Preserve deterministic saves, stable IDs and old behavior until explicit upgrade. Do not adjust schema/versions without coherent reader/UI/tests.
- Storage currently handles food. No weapon storage. Supplies/medical/ammo are future categories, not finished systems.
- No unselected adjacent systems, supply-budget refills, or staffing/capacity tuning to manufacture passes.
- Unity6000.6.3f1, GUIDs and .meta files remain protected. Native checks stay paused until the user resumes them.

## Most relevant remaining NPC investigation

Empty or interrupted PERSONAL SHOPPING returns can retain a task, suppress needs/recovery and interfere with next-day work. The existing R1 claim cleanup applies to courier order claims, not all personal-shopping states. In fixed F143 delivery fixture, consumer4first takes harm6090at(12,40), hunger100/energy0/hand0, Returning target4210with no courier order. It dies13740. Clerk3dies13260after a home/needs failure. These are concrete follow-up contexts, not proof of one universal cause.

The older R1 cartographer fixture also shows worse survival despite corrected generated delivery throughput. Do not hide it. One-agent consolidation should first reconcile source candidates and run integrated checks, then pick the next bounded NPC correction with actual failing-before tests and exact inventory/save evidence. No new gameplay task was authorized by requesting this transfer.

## Evidence interpretation

- `evidence/NPC-F143/verified107/`: authoritative fixed store outcomes;19focused cases/1338assertions; full711/743692; correct on-duty attendance metric and shopping-return deposits. All four26-hour runs,28mid-action checkpoint groups/840exact replay steps, finite food ledger. Legacy106four finals identical to original NPC137+World-reader validation.
- `evidence/NPC-F143/after107*`: equivalent earlier repeats; use verified107for final observation counters. World states repeat byte-for-byte, but observation refinements distinguish pantry redeposits from supplies brought home and on-duty attendance from personal shopping at work.
- `evidence/NPC-F141-R1/`:15focused cases/947assertions; full707/743301; old106digest; generated9/1death/health100, controls12/20, separate cartographer9deaths caveat.
- `evidence/NPC-F142-paired/`: historical old source7/4ablation results. Diagnostic variant sources are NOT shipping gameplay implementations.
- `evidence/store-baseline-validation/`: actual supplied106fixture failures, exact blocked door probes and pre-death states. This was not testing current143.
- `candidates/lead-integration/harness/validation/ui-pres-01a/`: newer UI4899/3and upgrade/World checks on Lead21338cf ancestry. It does not cover local R1/F143.
- `inputs/store-validation/VALIDATION.md`: prior static authoring/source tests, including a known old NPC137 LegacyUI outline failure. Do not relabel old logs as fresh checks.

Death snapshots and task/food CSVs are available per case. Review flags are heuristics, not automatic pathfinding defects. Finite food at a location is not proof a starving actor knows it or is allowed to reach it. API doubles, serialization, ABI checks and static geometry routes do not prove native Unity rendering/input or city performance at large scales.
