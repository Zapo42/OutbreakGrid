"""Read-only payload verification. Run from any directory after extracting the ZIP."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
m=json.loads((root/'MANIFEST.json').read_text())
for name,expected in m['files'].items():
    p=root/name
    assert not Path(name).is_absolute() and '..' not in Path(name).parts,name
    assert p.is_file() and p.stat().st_size==expected['bytes'],name
    assert hashlib.sha256(p.read_bytes()).hexdigest()==expected['sha256'],name
print('PASS',len(m['files']),'payload files; read-only size/SHA256 verification.')
