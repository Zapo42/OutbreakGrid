from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
for item in manifest['files']:
 p=(root/item['path']).resolve()
 if not p.is_relative_to(root):raise SystemExit('Unsafe payload path')
 data=p.read_bytes()
 if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:raise SystemExit('FAILED '+item['path'])
print('PASS: '+str(len(manifest['files']))+' payload files verified; source '+manifest['source_commit'])
