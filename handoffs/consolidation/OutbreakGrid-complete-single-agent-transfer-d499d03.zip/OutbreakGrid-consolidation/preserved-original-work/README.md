# Preserved unfinished original checkout

Original `/workspace/OutbreakGrid`, branch `work`, HEADc563076f608bd4e9fcbaeac18b0d1508c5f30232. It was not reset, cleaned or overwritten.

TRACKED-CHANGES.patch preserves tracked edits relative to that HEAD. UNTRACKED-FILES.zip preserves the untracked, non-ignored files reported by Git, including earlier CityReferences, generators and import checks. Ignored caches/build outputs and credentials were not collected. These are historical unfinished work, not replacements for the completed World branch. Restore in a separate checkout of the original HEAD for review; do not extract over the receiving integration checkout. STATUS.txt records the source state.
