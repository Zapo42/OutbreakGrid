using System;
using System.IO;
using System.Text.Json;
using Outbreak.Core;
using Outbreak.Persistence;
public static class ShellChecks
{
    public static int Main(string[] args)
    {
        string[] paths=Directory.GetFiles(args[0],"*.obmap2");
        if(paths.Length!=10)throw new InvalidOperationException("Expected ten building examples.");
        Array.Sort(paths,StringComparer.Ordinal);
        foreach(string path in paths)
        {
            WorldMap map=Documents.ParseMap(File.ReadAllText(path));
            string encoded=Documents.Encode(map.Capture());
            if(encoded!=Documents.Encode(Documents.ParseMap(encoded).Capture()))throw new InvalidOperationException("Map round-trip diverged.");
            using(JsonDocument metadata=JsonDocument.Parse(map.AuthoringJson))
            {
                if(metadata.RootElement.GetProperty("fixtures_materialized").GetBoolean() || metadata.RootElement.GetProperty("mechanics_enabled").GetBoolean())throw new InvalidOperationException("Draft shell activated mechanics.");
                World world=new World(map,214,encounter:true,hunger:true);
                int expected=metadata.RootElement.GetProperty("expected_room_count").GetInt32();
                if(world.ShelterRoomCount!=expected)throw new InvalidOperationException("Engine room discovery differs from template geometry.");
                Console.WriteLine("PASS real parser, exact round-trip, authoring hints and "+expected+" enclosed rooms: "+Path.GetFileName(path));
            }
        }
        return 0;
    }
}
