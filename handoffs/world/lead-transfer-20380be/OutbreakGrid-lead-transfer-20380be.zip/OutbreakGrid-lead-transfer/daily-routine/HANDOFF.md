# Daily-routine geometry handoff — local only

User-authorized controlled map for the existing NPC developer. Geometry/export is complete; direct contact with the separate NPC chat was unavailable. This document is the coordination handoff, not a claim that behavioral QA or cross-chat agreement occurred. No NPC decisions, movement, driving, cargo behavior or behavioral tests were edited.

## Exact inputs and outputs

- NPC source: `0aa8ec34aa168e4797bfcd672053755dcdfaa034` (npc/f137-familiar-greetings).
- World source: `20380bec26bf680865a2b22662872db115a390c4`, narrow World shared-file patches applied over that NPC source.
- Fixture: `source/RoutineFixture.cs`; exact compiled Core/Contracts/Persistence snapshot included in `source/snapshot`. No repository production source changed for this fixture.
- Seed: **214**. Existing `EncounterScenarios.LargerDistrictTrial(214)` supplies finite inventories, roles and home assignments. Fixture adds pedestrian geometry and park familiarity through existing public APIs.
- Local map: `/workspace/shared/outbreak-daily-routine/daily-routine-214.obmap2`.
- Local save: `/workspace/shared/outbreak-daily-routine/daily-routine-214.obsave`.
- Both are portable JSON documents; extensions do not change encoding. Open map through map import and save through save load. Use the **save** for assigned NPCs, staffing, shift state, shop identities and park familiarity; map-only import does not retain these.
- `assignments-and-routes.json`: every NPC's index, stable ID, role, home/workplace IDs, spawn, shifts; every checked path's cells and cardinal step count.
- `daily-routine-214.svg`: technical plan.
- Tick 0 / game time 07:00, paused before any NPC decision tick. No zombies, vehicles, fabricated supply or order-computer behavior.

## Assignments and shifts

Home A floor anchor (16,28), ID1680; Home B (36,28), ID1700; Home C (56,28), ID1720. All have an existing rest area and a capacity12 pantry with reserve4. Shared occupancy is deliberately retained from the existing NPC fixture.

| Stable NPC ID | Role | Home | Workplace | Shift |
|---|---|---|---|---|
| 1 | Courier | A | DC964 | 07:00–19:00 |
| 2 | Courier | B | DC964 | 07:00–19:00 |
| 3 | Clerk | A | Store A272 | 07:00–19:00 |
| 4, 5 | Consumers | A | — | none |
| 6 | Clerk | B | Store B676 | 07:00–19:00 |
| 7, 8 | Consumers | B | — | none |
| 9 | Clerk | C | Store C312 | 07:00–19:00 |
| 10, 11 | Consumers | C | — | none |

Couriers spawn at DC, clerks at their staffed stores, consumers at home. Couriers retain the existing DC order-fulfillment contract; no new forced destinations or delivery decisions were invented.

## Geometry, supply and intended routes

64×36 cells. Spine sidewalk y22, connected store/home/DC spurs, explicit crosswalks across road y20, sidewalks y21. Route acceptance disallows road and grass shortcuts, treats closed doors as potentially traversable, and respects shelves, stock boxes and phones as obstacles. This proves static access, not successful door opening, runtime occupancy handling, actor-specific route budgets or behavior.

One park: bounds (24,25)–(30,31), connected loop and central approach (27,28). All eleven NPCs explicitly know that destination via the NPC owner's `TryRememberPark`; this is an authored familiarity input, not hidden global knowledge. Existing discretionary leisure rules decide visits.

- Home→own-store paths: A33 / B27 / C33 cardinal steps. Shopping return follows the same connected corridor.
- Alternative shopping from Home A: Store B35 / Store C61 steps. These are intended diagnostic options, not forced shopper decisions.
- DC→store delivery approaches: A30 / B44 / C70 steps; reverse paths support return.
- Home→park: A23 / B27 / C47 steps; optional return home.
- Workers: assigned home↔work during existing shifts, rest/shop off duty according to existing NPC rules. Couriers' home/DC commutes share these connected spurs and spine; manifest paths measure DC/store delivery legs, not a simulated commute.
- Store shelf, store stock and home pantry approaches are individually checked; DC stock approach checked.

Initial finite supply: DC stock at(5,15):80 food/capacity100/reserve6. Store shelves at(16,8),(36,14),(56,8):6 food each. Store boxes at(17,4),(37,10),(57,4):empty/capacity6/reserve4. Home pantries at(17,26),(37,26),(57,26):empty/capacity12/reserve4. Each actor carries1 food and starts hunger10. Total109 food, distributed as80 DC +18 shelves +11 carried. Empty home/store boxes are retained intentionally from the existing fixture, making physical distribution necessary. This is not the unavailable four-death save.

## NPC developer coordination / diagnostics request

Reported baseline: **four NPC deaths with food remaining**. Its actual save, source revision and seed were not available in this workspace, so no reproduction or cause is claimed. Run this controlled save and the original baseline separately, using your existing behavior diagnostics. Capture per-NPC home/job identity, hunger/energy/health, household stocks, carried food, shelf availability, order ownership/state, access attempts and route interruptions; compare before death and across shift boundaries. Distinguish physical access, food availability at usable destinations, delivery allocation and work/home decision state. Return exact actor IDs/ticks and any failed coordinate pair for World geometry review. Do not infer that remaining aggregate food proves usable access or sufficient distribution. World will fix demonstrated geometry issues; NPC developer owns behavioral diagnosis and behavioral fixes.

## Verification and reproduction

PASS: build0 warnings/errors;11 assigned NPCs;21 connected cardinal pedestrian/interaction routes; map and save exact parse/capture roundtrips; separate-process exports and manifest byte-identical. No simulation ticks or survival outcome asserted. Native Unity testing remains paused. This is a controlled existing-style room fixture, not a regression run of the new two-room house generator.

From `source`, with .NET8:

```sh
dotnet build RoutineFixture.csproj -c Release -p:BaseIntermediateOutputPath=/tmp/routine-fixture/obj/ -p:OutputPath=/tmp/routine-fixture/bin/
dotnet /tmp/routine-fixture/bin/RoutineFixture.dll /tmp/routine-output
```

Actual SDK `/workspace/.outbreak-tools/dotnet/dotnet`; actual output `/workspace/shared/outbreak-daily-routine`. Cloud environment also requires DOTNET_CLI_HOME, XDG_RUNTIME_DIR, XDG_DATA_HOME and NUGET_PACKAGES pointing to the existing directories under `/workspace/.outbreak-tools` (as in the house handoff). Evidence: `build.log`, `geometry-checks.log`, `replay.log`. The separate completed house integration's documented unified runner evidence is in the live-houses packet: main131 PASS; NPC137 core PASS with a pre-existing LegacyUI failure independently reproduced unmodified. No unified runner or behavior code was changed by this fixture.

Keep local. Lead integrates source patches; NPC developer consumes this save and owns diagnostics. No merge, push, publication or claimed direct NPC-chat delivery.
