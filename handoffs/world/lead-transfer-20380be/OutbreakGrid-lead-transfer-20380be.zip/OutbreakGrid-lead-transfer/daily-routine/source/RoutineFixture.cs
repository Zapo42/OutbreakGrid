using System;
using System.IO;
using System.Collections.Generic;
using System.Text.Json;
using Outbreak.Core;
using Outbreak.Contracts;
using Outbreak.Persistence;
class RoutineFixture
{
 static void Check(bool ok,string why){if(!ok)throw new Exception(why);}
 static void Main(string[] args){
 string output=args[0];Directory.CreateDirectory(output);
 // Reuse the NPC owner's existing assignments and finite inventories, without running decisions.
 var saved=EncounterScenarios.LargerDistrictTrial(214).Capture();saved.map.name="Daily routine geometry 214";var map=WorldMap.Restore(saved.map);
 // Connect every doorstep to a shared sidewalk spine; crossings replace the single road cell.
 for(int x=6;x<=59;x++)map.Set(x,22,Terrain.Sidewalk);
 int[] sx={14,34,54},sy={3,9,3};
 for(int i=0;i<3;i++){
  int x=sx[i]-1;for(int y=sy[i]+3;y<=22;y++)map.Set(x,y,y==20?Terrain.Crosswalk:Terrain.Sidewalk);
  for(int y=22;y<=28;y++)map.Set(sx[i]+5,y,Terrain.Sidewalk);
 }
 for(int y=17;y<=22;y++)map.Set(7,y,y==20?Terrain.Crosswalk:Terrain.Sidewalk);
 // A single bounded park, with a connected loop and a known central leisure destination.
 for(int y=25;y<=31;y++)for(int x=24;x<=30;x++)map.Set(x,y,Terrain.Grass);
 for(int x=24;x<=30;x++){map.Set(x,25,Terrain.Sidewalk);map.Set(x,31,Terrain.Sidewalk);}
 for(int y=25;y<=31;y++){map.Set(24,y,Terrain.Sidewalk);map.Set(30,y,Terrain.Sidewalk);}
 for(int y=22;y<=28;y++)map.Set(27,y,Terrain.Sidewalk);
 saved.map=map.Capture();var world=World.Restore(saved);
 for(int i=0;i<world.Count;i++)Check(world.TryRememberPark(i,27,28),"Park familiarity rejected");
 saved=world.Capture();string json=Documents.Encode(saved);
 Check(Documents.Encode(Documents.ParseSave(json).Capture())==json,"Save roundtrip");
 string mapJson=Documents.Encode(saved.map);Check(Documents.Encode(Documents.ParseMap(mapJson).Capture())==mapJson,"Map roundtrip");
 Documents.Write(Path.Combine(output,"daily-routine-214.obsave"),json);Documents.Write(Path.Combine(output,"daily-routine-214.obmap2"),mapJson);
 var routes=new List<object>();
 Action<string,int,int,int,int> route=(name,ax,ay,bx,by)=>{
  int w=map.Width;var q=new Queue<int>();var previous=new Dictionary<int,int>();int start=ay*w+ax,goal=by*w+bx;q.Enqueue(start);previous[start]=-1;
  while(q.Count>0&&!previous.ContainsKey(goal)){int cell=q.Dequeue();foreach(var d in new[]{(1,0),(-1,0),(0,1),(0,-1)}){int x=cell%w+d.Item1,y=cell/w+d.Item2,key=y*w+x;if(!map.Contains(x,y)||previous.ContainsKey(key))continue;Terrain t=map.Get(x,y);bool walk=t==Terrain.DoorClosed||map.CanWalk(x,y);if(!walk||t==Terrain.Grass||t==Terrain.Road)continue;previous[key]=cell;q.Enqueue(key);}}
  Check(previous.ContainsKey(goal),"Disconnected route "+name);var cells=new List<int[]>();for(int c=goal;c!=-1;c=previous[c])cells.Add(new[]{c%w,c/w});cells.Reverse();routes.Add(new{name,steps=cells.Count-1,cells});
 };
 for(int i=0;i<3;i++){
 route("home-"+i+" to own store",sx[i]+2,28,sx[i]+1,sy[i]+3);
 route("DC to store-"+i,4,17,sx[i]+1,sy[i]+3);
 route("home-"+i+" to park",sx[i]+2,28,27,28);
 // Validate physical access to each stock/shelf interaction approach.
 route("store-"+i+" shelf approach",sx[i]+1,sy[i]+3,sx[i]+1,sy[i]+5);
 route("store-"+i+" stock approach",sx[i]+1,sy[i]+3,sx[i]+2,sy[i]+1);
 route("home-"+i+" pantry approach",sx[i]+2,28,sx[i]+2,26);
 }
 route("short alternative shopping home-0 to store-1",16,28,35,12);
 route("long alternative shopping home-0 to store-2",16,28,55,6);
 route("DC stock approach",4,17,4,15);
 var people=new List<object>();for(int i=0;i<world.Count;i++){var a=world.ActorAt(i);people.Add(new{index=i,id=a.id,occupation=world.AssignedOccupation(i).ToString(),homeId=a.assignedHouseId,spawn=new[]{a.x,a.y},storeId=a.clerkStoreId,distributionCenterId=a.distributionCenterId,shift=world.AssignedOccupation(i)==HumanOccupation.Consumer?"none":"07:00-19:00",homeGroup=i<2?i:(i-2)/3});}
 File.WriteAllText(Path.Combine(output,"assignments-and-routes.json"),JsonSerializer.Serialize(new{seed=214,npcSource="0aa8ec34aa168e4797bfcd672053755dcdfaa034",worldSource="20380bec26bf680865a2b22662872db115a390c4",tick=saved.tick,clockHour=world.CourierClockHour,people,routes},new JsonSerializerOptions{WriteIndented=true}));
 Console.WriteLine("PASS: "+world.Count+" assigned NPCs; "+routes.Count+" connected cardinal pedestrian/access routes; map/save exact roundtrips; no behavior ticks.");
 }
}
